import React, { useState } from "react"

// Importing functions from react bootstrap for styling
import { Alert } from "react-bootstrap"


import { BsPlusCircleFill } from "react-icons/bs";

import Button from 'react-bootstrap/Button';



// Importing useAuth() function from AuthContext.js
import { useAuth } from "../AuthContext"

// Importing functions from react-router-dom for linking different pages of the app
import { useHistory } from "react-router-dom"

function Home() {

    //Creating an error state that is used for displaying error messages in the home page
    const [error, handleError] = useState("")

    // Getting logout function from ../Auth Context, to use in the home page.
    const { logout } = useAuth()

    
    // Creating a const variable history that can be used for redirecting the user to another page after an event is triggered
    const history = useHistory()

    // Creating an asynchronous function that is called when the log out button is clicked by a user
    async function handleLogout() {
        handleError("")
        try {
            // Wait for the logout function to finish
            await logout()
            // The user is redirected to the login page after logging out of the app
            history.push("/login")
        } catch {
            handleError("Log out failed")
        }
    }

    async function handleNotification() {
        handleError("")
        try {
            history.push("/notify")
        } catch {
            handleError("No Notification")
        }
    }

    
    async function handleUpload() {
        handleError("")
        try {
            history.push("/UploadImages")
        } catch {
            handleError("Error Access Denied")
        }
    }

    return (

        < section>

            <nav>

                <h1>Welcome to Instagram </h1>
                {/* If an error exists, a Bootstrap alert is rendered out.*/}
                {error && <Alert variant="danger">{error}</Alert>}
                {/* Log out button which when clicked by a user, logs them out of the app */}
                <Button variant="dark" onClick={handleLogout}>Log Out</Button>
                <Button variant="dark" onClick={handleNotification}>Notification</Button>
        
            </nav>
<body>
  <div class="wrapper">
    <div data-reactroot>
      <div>

         
        <div>                 
            
            
             </div>

      </div>
    </div>
  </div>
</body>
        
       <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          fontSize : 69,
        }}
        
      ><Button variant="dark" onClick={handleUpload}><BsPlusCircleFill/></Button>
      </div>



    
        </section >

        
    )
}

export default Home