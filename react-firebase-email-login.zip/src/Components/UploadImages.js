import React, { useState } from "react"
import { Alert } from "react-bootstrap"
import Button from 'react-bootstrap/Button';
import { useHistory } from "react-router-dom"

import { storage } from "../firebase";


function UploadImages() {

    const [error, handleError] = useState("")

    
    const history = useHistory()


  function handleHome() {
        handleError("")
        try {
    
            history.goBack("/")
        } catch {
            handleError("No Home Page")
        }
    }

        const[image, setImage] = useState(null);


    const handleChange = e => {
        if (e.target.files[0]) {
            setImage(e.target.files[0])
        }
    };


    const handleUpload = () => {
        const uploadTask = storage.ref(`images/${image.name}`).put(image);
        uploadTask.on(
            "state_changed",
            snapshot => {},
            error => {
                console.log(error);
            },
            () => {
                storage
                .ref("images")
                .child(image.name)
                .getDownloadURL()
                .then(url => {
                    console.log(url);
                });    
            }
        );
    };
    console.log("image: " , image);
    

        return (
            < section>
                <nav>
                <h1>Upload Image</h1>
                {error && <Alert variant="danger">{error}</Alert>}
                <input type ="file" onChange={handleChange} />
                <Button variant="dark" onClick={handleUpload}>Upload</Button>
                <Button variant="dark" onClick={handleHome}>Go Backkk</Button>
                </nav>
        
            </section >
            
            
        );
    };


export default UploadImages